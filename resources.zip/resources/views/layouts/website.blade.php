<!doctype html>
<html class="no-js" lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>doglovers</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="shortcut icon" type="image/x-icon" href="{{asset('contents/website')}}/images/dog.png">


    <link rel="stylesheet" href="{{asset('contents/website')}}/css/bootstrap.min.css">


    <link rel="stylesheet" href="{{asset('contents/website')}}/css/icon-font.min.css">


    <link rel="stylesheet" href="{{asset('contents/website')}}/css/plugins.css">


    <link rel="stylesheet" href="{{asset('contents/website')}}/css/style.css">



</head>

<body>


    <div class="header-section section">



        <div class="header-bottom header-bottom-one header-sticky">
            <div class="container">
                <div class="row align-items-center justify-content-between">

                    <div class="col mt-15 mb-15">

                        <div class="header-logo">
                            <a href="{{url('/')}}">
                            <img src="{{asset('contents/website')}}/images/loggo.png" width="100" height="100" alt="logo">
                            
                           
                        </a>
                        </div>

                    </div>

                    <div class="col order-12 order-lg-2 order-xl-2 d-none d-lg-block">

                        <div class="main-menu">
                            <nav>
                                <ul>
                                    <li class="active"><a href="{{url('/')}}">HOME</a></li>
                                    <li class="menu-item"><a href="{{url('health')}}">Health</a>

                                    </li>
                                    <li class="menu-item-has-children"><a href="#">PAGES</a>
                                        <ul class="mega-menu two-column">
                                            <li><a href="#">About</a>
                                                <ul>
                                                    <li><a href="{{url('about')}}">About</a></li>
                                                    <li><a href="{{url('faq')}}">Faq</a></li>



                                                </ul>
                                            </li>

                                            <li><a href="#">Events</a>
                                                <ul>
                                                    <li><a href="{{url('donate')}}">Donate</a></li>
                                                    <li><a href="{{url('breed')}}">Breed</a></li>

                                                    <!--                                                   
                                                          <li><a href="donate-ad-breed.html">Adopt</a></li>-->
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="menu-item"><a href="{{url('blog')}}">Blog</a>

                                    </li>
                                    <li><a href="{{url('contact')}}">Contact</a></li>
                                </ul>
                            </nav>
                        </div>

                    </div>


                </div>
            </div>
        </div>
    </div>


    @yield('contents')




    <div class="footer-section section bg-ivory">


        <div class="footer-top-section section pt-90 pb-50">
            <div class="container">

                <div class="row">


                    <div class="col-lg-3 col-md-6 col-12 mb-40">
                        <div class="footer-widget">

                            <h4 class="widget-title">CONTACT INFO</h4>


                            <p class="contact-info">
                                <span>Phone</span>
                                <a href="tel:01234567890">017XXXXXX</a>
                                <a href="tel:01234567891">017XXXXXX</a>
                            </p>

                            <p class="contact-info">
                                <span>Web</span>

                                <a href="#">www.dogloversbd.com</a>
                            </p>

                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-12 mb-40">
                        <div class="footer-widget">

                            <h4 class="widget-title">CUSTOMER CARE</h4>

                            <ul class="link-widget">
                                <li><a href="{{url('about')}}">About </a></li>

                                <li><a href="{{url('blog')}}">blog</a></li>
                                <li><a href="{{url('contact')}}">Contact</a></li>
                            </ul>

                        </div>
                    </div>







                </div>

            </div>
        </div>

        <div class="footer-bottom-section section">
            <div class="container">
                <div class="row">


                    <div class="col-lg-6 col-12">
                        <div class="footer-copyright">
                            <p>&copy; Copyright, 2018 All Rights Reserved by <a href="https://freethemescloud.com/">dogloversbd.com</a></p>
                        </div>
                    </div>




                </div>
            </div>
        </div>


    </div>





    <script src="{{asset('contents/website')}}/js/vendor/modernizr-2.8.3.min.js"></script>

    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <script src="assets/js/popper.min.js"></script>

    <script src="assets/js/bootstrap.min.js"></script>

    <script src="assets/js/plugins.js"></script>


    <script src="assets/js/main.js"></script>

</body>

</html>
