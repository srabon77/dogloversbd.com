 @extends('layouts.admin')
 
 
  @section('content') 
  
 
 
 <div class="row">
                    <div class="col-lg-12">
                        <div class="card card-outline-info">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h4 class="m-b-0 text-white">All Contact Message</h4>
                                    </div>
                                    <div class="col-md-4 text-right">
                                        <a href="{{url('admin/contact')}}" class="btn btn-sm btn-warning">Demo </a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                               <div class="table-responsive">
                                    <table class="table color-table dark-table">
                                        <thead>
                                            <tr>
                                                
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Message</th>
                                                <th>Time</th>
                                                <th>Manage</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                           
                                           @foreach($allCon as $data)
                                            <tr>
                                                <td>{{$data->conus_name}}</td>
                                                <td>{{$data->conus_email}}</td>
                                                <td>{{$data->conus_sub}}</td>
                                                <td>{{str_limit($data->conus_mess,20)}}</td>
                                                <td>{{$data->created_at}}</td>
                                                <td>
                                                    
                                                    <a href="{{url('admin/contact/view/'.$data->conus_slug)}}" class=""><i class="fa fa-plus-square text-primary"></i> </a>
                                                    
                                                    <a href="#" class=""><i class="fa fa-trash text-danger"></i> </a>
                                                
                                                
                                                </td>
                                                
                                            </tr>
                                            @endforeach
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                            <div class="card-footer">
                                
                                <a href="#" class="btn btn-sm btn-primary" >Excel </a>
                            </div>
                        </div>
                    </div>
                </div>






@endsection