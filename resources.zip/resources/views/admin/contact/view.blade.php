 @extends('layouts.admin') 

 @section('content')



<div class="row">
    <div class="col-lg-12">
        <div class="card card-outline-info">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-8">
                        <h4 class="m-b-0 text-white">All Contact Message</h4>
                    </div>
                    <div class="col-md-4 text-right">
                        <a href="#" class="btn btn-sm btn-warning">Demo </a>
                    </div>
                </div>
            </div>



            <div class="card-body">

                <div class="row">

                    <div class="col-md-2"></div>
                    <div class="col-md-8">


                        <table class="table table-responsive table-bordered table-striped table-hover view_customize_table">
                            
                            
                            
                            <tr>
                            
                            <td>Name</td>
                                <td>:</td>
                                <td>{{$data->conus_name}}</td>
                            
                            </tr>
                            
                            
                            
                             <tr>
                                 
                            
                            <td>Email</td>
                                <td>:</td>
                                <td>{{$data->conus_email}}</td>
                            
                            </tr>
                            
                            
                            
                             <tr>
                            
                            <td>Phone</td>
                                <td>:</td>
                                <td>{{$data->conus_sub}}</td>
                            
                            </tr>
                            
                              <tr>
                            
                            <td>Message</td>
                                <td>:</td>
                                <td>{{$data->conus_mess}}</td>
                            
                            </tr>
                            
                            
                            
                             <tr>
                            
                            <td>Time</td>
                                <td>:</td>
                                <td>{{$data->created_at}}</td>
                            
                            </tr>
                            
                            





                        </table>




                    </div>
                    <div class="col-md-2"></div>




                </div>






            </div>

            <div class="card-footer">

                <a href="#" class="btn btn-sm btn-primary">Excel </a>
            </div>
        </div>
    </div>
</div>






@endsection
