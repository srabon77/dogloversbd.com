 @extends('layouts.admin')
 
 
  @section('content') 
  
 
 
 <div class="row">
                    <div class="col-lg-12">
                        <div class="card card-outline-info">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-md-8">
                                        <h4 class="m-b-0 text-white">All User information</h4>
                                    </div>
                                    <div class="col-md-4 text-right">
                                        <a href="#" class="btn btn-sm btn-warning">Add User </a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                               <div class="table-responsive">
                                    <table class="table color-table dark-table">
                                        <thead>
                                            <tr>
                                                
                                                <th> Name</th>
                                                <th>Email</th>
                                                <th>Phone</th>
                                                <th>Message</th>
                                                <th>Manage</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                           
                                           @foreach($all as $data)
                                            <tr>
                                                
                                                <td>{{$data->name}}</td>
                                                <td>{{$data->email}}</td>
                                                <td></td>
                                                <td></td>
                                                <td>
                                                     
                                                      <a href="#" class=""><i class="fa fa-plus-square text-primary"></i> </a>
                                                   
                                                    <a href="#" class=""><i class="fa fa-trash text-danger"></i> </a>
                                                
                                                
                                                </td>
                                            </tr>
                                            @endforeach
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                            <div class="card-footer">
                                
                                <a href="#" class="btn btn-sm btn-primary" >Excel </a>
                            </div>
                        </div>
                    </div>
                </div>






@endsection