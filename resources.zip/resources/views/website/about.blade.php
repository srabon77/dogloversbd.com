 @extends('layouts.website')
 
 
  @section('contents')

    <div class="page-banner-section section">
        <div class="page-banner-wrap row row-0 d-flex align-items-center ">


            <div class="col-lg-4 col-12 order-lg-2 d-flex align-items-center justify-content-center">
                <div class="page-banner">
                    <h1>About us</h1>
                    <p>similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita</p>
                    <div class="breadcrumb">
                        <ul>
                            <li><a href="index.html">HOME</a></li>
                            <li><a href="about.html">about</a></li>
                        </ul>
                    </div>
                </div>
            </div>


            <div class="col-lg-4 col-md-6 col-12 order-lg-1">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/back.jpg"width="570" height="232" alt="Banner"></a></div>
            </div>


            <div class="col-lg-4 col-md-6 col-12 order-lg-3">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/cute.jpg"width="570" height="232" alt="Banner"></a></div>
            </div>

        </div>
    </div>

    <div class="about-section section mt-90 mb-30">
        <div class="container">

            <div class="row row-30 mb-40">


                <div class="about-image col-lg-6 mb-50">
                    <img src="{{asset('contents/website')}}/images/about/dogg.jpg" height="483" width="585" alt="ban">
                </div>


                <div class="about-content col-lg-6">
                    <div class="row">
                        <div class="col-12 mb-50">
                            <h1>WELCOME TO <span>Dogloversbd</span></h1>
                            <p>this is a full wesite about dog information center. in our country Bangladesh their is no such dog information website. so we decided to make a full website.</p>
                        </div>

                        <div class="col-12 mb-50">
                            <h4>WE START AT 2018</h4>
                            <p>we provide how all this mistaken idea of denouncing pleasure and sing pain was born an will give you a complete account of the system, and expound the actual teachings of the eat explorer of the truth, the mer of human.</p>
                        </div>



                    </div>
                </div>

            </div>

            <div class="row row-10 mb-60">


                <div class="col-md-3 mb-20">
                    <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/do.png" height="245" width="270" alt="Banner"></a></div>
                </div>


                <div class="col-md-9">
                    <div class="row row-10">

                        <div class="col-md-6 col-12 mb-20">
                            <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/thum.jpg" alt="Banner"weidth="430" height="250"></a></div>
                        </div>
                        <div class="col-md-6 col-12 mb-20">
                            <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/doge.png" alt="Banner"weidth="430" height="250"></a></div>
                        </div>
                        

                    </div>
                </div>

            </div>


            <div class="about-mission-vission-goal row row-20 mb-40">

                <div class="col-lg-4 col-md-6 col-12 mb-40">
                    <h3>OUR VISSION</h3>
                    <p>we provide how all this mistaken idea of denouncing pleasure and sing pain was born an will give you a ete account of the system, and expound the actual teangs the eat explorer of the truth, the mer of human tas assumenda est, omnis dolor repellend</p>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mb-40">
                    <h3>OUR MISSION</h3>
                    <p>we provide how all this mistaken idea of denouncing pleasure and sing pain was born an will give you a ete account of the system, and expound the actual teangs the eat explorer of the truth, the mer of human tas assumenda est, omnis dolor repellend</p>
                </div>

                <div class="col-lg-4 col-md-6 col-12 mb-40">
                    <h3>OUR GOAL</h3>
                    <p>we provide how all this mistaken idea of denouncing pleasure and sing pain was born an will give you a ete account of the system, and expound the actual teangs the eat explorer of the truth, the mer of human tas assumenda est, omnis dolor repellend</p>
                </div>

            </div>

            <div class="row mb-30">


                <div class="about-section-title col-12 mb-50">
                    <h3>YOU CAN CHOOSE US BECAUSE <br>WE ALWAYS PROVIDE IMPORTANCE...</h3>
                    <p>we provide how all this mistaken idea of denouncing pleasure and sing pain was born will give you a complete account of the system, and expound the actual</p>
                </div>


                <div class="about-feature col-lg-7 col-12">
                    <div class="row">



                        <div class="col-md-6 col-12 mb-30">
                            <h4>QUALITY PRODUCT</h4>
                            <p>we provide how all this mistaken dea of denouncing pleasure and sing </p>
                        </div>

                        <div class="col-md-6 col-12 mb-30">
                            <h4>Fast response</h4>
                            <p>we provide how all this mistaken dea of denouncing pleasure and sing </p>
                        </div>


                        <div class="col-md-6 col-12 mb-30">
                            <h4>Replying customer email</h4>
                            <p>we provide how all this mistaken dea of denouncing pleasure and sing </p>
                        </div>



                        <div class="col-md-6 col-12 mb-30">
                            <h4>24/7 SUPPORT</h4>
                            <p>we provide how all this mistaken dea of denouncing pleasure and sing </p>
                        </div>

                    </div>
                </div>


                <div class="about-feature-banner col-lg-5 col-12 mb-30">
                    <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/bann.jpg" width="400" height="455" alt="Banner"></a></div>
                </div>

            </div>

        </div>
    </div>

    <div class="team-section section">
        <div class="col p-0"><img src="{{asset('contents/website')}}/images/team/doo.jpg" width="1920" height="663" alt="Full Width Team" style="max-width: 100%;"></div>
    </div>

   @endsection