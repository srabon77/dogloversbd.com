 @extends('layouts.website')
 
 
  @section('contents')


<div class="container">

    <center>
        <div class="p-3 mb-2 bg-white text-dark">
            <h1>Welcome To Dogloversbd.com</h1>
        </div>
    </center>
</div>




<div class="banner-section section mb-60">
    <div class="container">
        <div class="row row-10">


            <div class="col-md-8 col-12 mb-30">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/7014296-dog-fall.jpg" width="770" height="320"  alt="Banner"></a></div>
            </div>


            <div class="col-md-4 col-12 mb-30">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/Cute.jpg" width="380" height="320" alt="Banner"></a></div>
            </div>

        </div>
    </div>
</div>








<div class="product-section section mb-60">
    <div class="container">
        <div class="row">


            <div class="col-12 mb-40">
                <div class="section-title-one" data-title="Available dogs">
                    <h1>Available dogs</h1>
                </div>
            </div>


            <div class="col-12">
                <div class="row">

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">

                                <a href="{{url('taison')}}" class="img">
                                <img src="{{asset('contents/website')}}/images/product/tai.jpg" alt="Product Image"height="320" wight="270"></a>


                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="taison.html">Taison</a></h5>

                                </div>



                            </div>

                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">



                                <a href="{{url('tiger')}}" class="img"><img src="{{asset('contents/website')}}/images/product/tiger.jpg" alt="Product Image"height="320" wight="270"></a>


                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="tiger.html">Tiger</a></h5>

                                </div>




                            </div>

                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">

                                <a href="{{url('jack')}}" class="img"><img src="{{asset('contents/website')}}/images/product/jack.jpg" alt="Product Image"height="320" wight="270"></a>


                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="jack.html">Jack</a></h5>

                                </div>




                            </div>

                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">



                                <a href="{{url('max')}}" class="img"><img src="{{asset('contents/website')}}/images/product/max.jpg" alt="Product Image"height="320" wight="270"></a>


                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="max.html">Max</a></h5>

                                </div>



                            </div>

                        </div>

                    </div>


                </div>



            </div>

        </div>





    </div>

</div>



<div class="product-section section mb-60">
    <div class="container">
        <div class="row">


            <div class="col-12 mb-40">
                <div class="section-title-one" data-title="BEST HIT">
                    <h1>BEST HIT</h1>
                </div>
            </div>


            <div class="col-12">
                <div class="row">

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">

                                <a href="{{url('romeo')}}" class="img"><img src="{{asset('contents/website')}}/images/product/romeo.jpg" alt="Product Image"height="320" wight="270"></a>


                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="romeo.html">Romeo-Juliet</a></h5>

                                </div>



                            </div>

                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">



                                <a href="{{url('tuck')}}" class="img"><img src="{{asset('contents/website')}}/images/product/tuck.jpg" alt="Product Image"height="320" wight="270"></a>


                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="tuck.html">Tucker</a></h5>

                                </div>




                            </div>

                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">

                                <a href="{{url('rocky')}}" class="img"><img src="{{asset('contents/website')}}/images/product/Rocky.jpg" alt="Product Image"height="320" wight="270"></a>


                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="rocky.html">Rocky</a></h5>

                                </div>




                            </div>

                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">



                                <a href="{{url('harry')}}" class="img"><img src="{{asset('contents/website')}}/images/product/harry.jpg" alt="Product Image"height="320" wight="270"></a>


                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="harry.html">Harry</a></h5>

                                </div>



                            </div>

                        </div>

                    </div>


                </div>



            </div>

        </div>





    </div>

</div>









<div class="banner-section section mb-90">
    <div class="container">
        <div class="row">


            <div class="col-12">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/dog-lying-down-8.jpg" width="1170" height="350" alt="Banner"></a></div>
            </div>

        </div>
    </div>
</div>






<div class="product-section section mb-60">
    <div class="container">
        <div class="row">


            <div class="col-12 mb-40">
                <div class="section-title-one" data-title="NEW Posted">
                    <h1>NEW Posted</h1>
                </div>
            </div>


            <div class="col-12">
                <div class="row">

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">



                                <a href="{{url('duck')}}" class="img"><img src="{{asset('contents/website')}}/images/product/duck.jpg" alt="Product Image" width="270" height="320"></a>





                            </div>
                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="duck.html">Duck</a></h5>

                                </div>


                            </div>



                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">



                                <a href="{{url('oliver')}}" class="img"><img src="{{asset('contents/website')}}/images/product/oliver.jpg" alt="Product Image"width="270" height="320"></a>





                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="oliver.html">oliver</a></h5>

                                </div>


                            </div>

                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">

                                <a href="{{url('bear')}}" class="img"><img src="{{asset('contents/website')}}/images/product/bear.jpg" alt="Product Image"width="270" height="320"></a>





                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="bear.html">Bear</a></h5>

                                </div>


                            </div>

                        </div>

                    </div>

                    <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">

                        <div class="ee-product">


                            <div class="image">



                                <a href="{{url('badsha')}}" class="img"><img src="{{asset('contents/website')}}/images/product/badsha.jpg" alt="Product Image"width="270" height="320"></a>





                            </div>


                            <div class="content">


                                <div class="category-title">


                                    <h5 class="title"><a href="badsha.html">Badsha</a></h5>

                                </div>




                            </div>

                        </div>

                    </div>



                </div>
            </div>

        </div>
    </div>
</div>

<div class="banner-section section mb-60">
    <div class="container">
        <div class="row">


            <div class="col-md-4 col-12 mb-30">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/3.jpg" width="320" height="244"  alt="Banner"></a></div>
            </div>


            <div class="col-md-4 col-12 mb-30">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/4.jpg"width="320" height="244" alt="Banner"></a></div>
            </div>


            <div class="col-md-4 col-12 mb-30">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/dog-photography-sobaka-beg.jpg"width="320" height="244" alt="Banner"></a></div>
            </div>

        </div>
    </div>
</div>

@endsection
