
    @extends('layouts.website')
 
 
  @section('contents')


    <div class="page-banner-section section">
        <div class="page-banner-wrap row row-0 d-flex align-items-center ">

            
            <div class="col-lg-4 col-12 order-lg-2 d-flex align-items-center justify-content-center">
                <div class="page-banner">
                    <h1>Events</h1>
                    <p>similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita</p>
                    <div class="breadcrumb">
                        <ul>
                            <li><a href="index.html">HOME</a></li>
                            <li><a href="donate.html">Donate</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4 col-md-6 col-12 order-lg-1">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/small-dog-breeds.jpg"weidth="570" height="232" alt="Banner"></a></div>
            </div>

            
            <div class="col-lg-4 col-md-6 col-12 order-lg-3">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/do.png"weidth="570" height="232" alt="Banner"></a></div>
            </div>

        </div>
    </div>
   
    <div class="blog-section section mt-90 mb-50">
        <div class="container">
            <div class="row row-40">

                <div class="col-lg-8 col-12 order-1 order-lg-2 mb-40">
                    <div class="row">


                        <div class="col-12 mb-40">
                            <div class="ee-blog">
                                <a href="donate.html" class="image"><img src="{{asset('contents/website')}}/images/blog/dog-paw-care.jpg"width="770" height="386" alt="Blog Image"></a>
                                <div class="content">
                                    <h1><a href="donate.html">SUSTAINING DONATIONS </a></h1>

                                    <h5>Want to help on a regular basis? You can make monthly donations to Rural Dog Rescue. This program allows all of our donors an opportunity to set up a recurring gift for as little as $5 a month. </h5>


                                    <li>For $100 per month, you can save an animal from a high-kill shelter.</li>
                                    <li>For $50 per month, you can help pay medical bills for our rescued animals.</li>
                                    <li>For $25 per month, you can help feed a homeless dog.</li>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 mb-40">
                            <div class="ee-blog">

                                <div class="content">
                                    <h1><a href="donate.html">SPONSOR A RESCUE DOG </a></h1>

                                    <p>Many people are not in a position to foster or adopt a dog, but would still like to help! A great way to do this is to sponsor a dog with Rural Dog Rescue. </p>



                                </div>
                            </div>
                        </div>

                        <div class="col-12 mb-40">
                            <div class="ee-blog">

                                <div class="content">
                                    <h1><a href="donate.html">DONATE IN MEMORY OF... </a></h1>

                                    <p>If you would like to make a donation in memory of someone (whether a human or animal), your donation will assist us in our mission of rescuing the “underdog.” You will receive an acknowledgement of your gift via email or letter. Your donation in memory of your loved one will help a future Rural Dog find a loving family. </p>



                                </div>
                            </div>
                        </div>
                        
                         <div class="col-12 mb-40">
                        <div class="ee-blog">
                            
                            <div class="content">
                                <h3><a href="donate.html">Facebook group </a></h3>
                               
                                <p>also you can post in our FB group</p>
                            </div>
                            <a href="donate.html" class="image"><img src="{{asset('contents/website')}}/images/blog/blog%20(1).png"width="770" height="386" alt="Blog Image"></a>
                        </div>
                    </div>


                    </div>

                   

                </div>

                <div class="col-lg-4 col-12 order-2 order-lg-1">

                    
                    <div class="blog-sidebar mb-40">

                        <h4 class="title">CATEGORIES</h4>

                         <ul>
                        <li><a href="oliver.html">Labrador Retriever</a></li>
                        <li><a href="rick-martin.html">Bulldog</a></li>
                        <li><a href="harry.html">Beagle</a></li>
                        <li><a href="tiger.html">Shiba Inu</a></li>
                        <li><a href="bear.html">German Shepherd</a></li>
                        <li><a href="tuck.html">Finnish Spitz</a></li>
                        <li><a href="cooper.html">Golden Retriever</a></li>
                        <li><a href="duck.html">Rhodesian Ridgeback</a></li>
                        
                    </ul>

                    </div>

                    
                    <div class="blog-sidebar mb-40">

                        <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/2.jpg" width="256" height="284" alt="Banner"></a></div>

                    </div>

                    


                </div>

            </div>
        </div>
    </div>
   

@endsection