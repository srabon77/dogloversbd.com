 @extends('layouts.website')
 
 
  @section('contents')


    <div class="page-banner-section section">
        <div class="page-banner-wrap row row-0 d-flex align-items-center ">

            
            <div class="col-lg-4 col-12 order-lg-2 d-flex align-items-center justify-content-center">
                <div class="page-banner">
                    <h1>Health</h1>
                   
                    <div class="breadcrumb">
                        <ul>
                            <li><a href="index.html">HOME</a></li>
                            <li><a href="health.html">Health</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4 col-md-6 col-12 order-lg-1">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/care1.jpg"weidth="570" height="232" alt="Banner"></a></div>
            </div>

            
            <div class="col-lg-4 col-md-6 col-12 order-lg-3">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/care2.jpg"weidth="570" height="232" alt="Banner"></a></div>
            </div>

        </div>
    </div>
    


    <div class="blog-section section mt-90 mb-50">
        <div class="container">
            <div class="row row-40">

                <div class="col-lg-8 col-12 order-1 order-lg-2 mb-40">
                    <div class="row">

                        
                        <div class="col-12 mb-40">
                            <div class="ee-blog">
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/care3.jpg" width="770" height="386" alt="Blog Image"></a>
                                <div class="content">
                                    <h3>give nutretion food</h3>

                                    <h5>Let’s Talk Dog Nutrition — 6 Essential Nutrients Dogs Need. </h5>

                                    <li>water</li>

                                    <li>protine</li>
                                    <li>fat</li>
                                    <li>vitamins</li>

                                    <li>minarels</li>
                                    <li>Carbohydred</li>

                                </div>
                            </div>
                        </div>

                        
                        <div class="col-12 mb-40">
                            <div class="ee-blog">

                                <div class="content">
                                    <h3>cleaning</h3>


                                </div>
                                <a href="health.html" class="image"><img src="{{asset('contents/website')}}/images/blog/care4.jpg"width="770" height="386" alt="Blog Image"></a>

                            </div>
                        </div>

                       
                        <div class="col-12 mb-40">
                            <div class="ee-blog">
                                <div class="content">
                                    <h3>play with them</h3>


                                </div>
                                <a href="health.html" class="image"><img src="{{asset('contents/website')}}/images/blog/care5.jpg"width="770" height="386" alt="Blog Image"></a>

                            </div>
                        </div>

                        <div class="col-12 mb-40">
                            <div class="ee-blog">

                                <div class="content">
                                    <h3>take to the veterinary sergen</h3>


                                </div>
                                <a href="health.html" class="image"><img src="{{asset('contents/website')}}/images/blog/care6.jpg"width="770" height="386" alt="Blog Image"></a>

                            </div>
                        </div>


                        <div class="col-12 mb-40">
                            <div class="ee-blog">

                                <div class="content">
                                    <h3>please for more update like our facebook page</h3>
                                    <p>we have their 24/7</p>


                                </div>
                                <a href="https://www.facebook.com/dogloversdhaka/" class="image"><img src="{{asset('contents/website')}}/images/blog/sc.png"width="770" height="386" alt="Blog Image"></a>

                            </div>
                        </div>

                    </div>

                    

                </div>

                <div class="col-lg-4 col-12 order-2 order-lg-1">

                    
                    <div class="blog-sidebar mb-40">

                        <h4 class="title">CATEGORIES</h4>

                        <ul>
                            <li><a href="oliver.html">Labrador Retriever</a></li>
                            <li><a href="rick-martin.html">Bulldog</a></li>
                            <li><a href="harry.html">Beagle</a></li>
                            <li><a href="tiger.html">Shiba Inu</a></li>
                            <li><a href="bear.html">German Shepherd</a></li>
                            <li><a href="tuck.html">Finnish Spitz</a></li>
                            <li><a href="cooper.html">Golden Retriever</a></li>
                            <li><a href="duck.html">Rhodesian Ridgeback</a></li>

                        </ul>

                    </div>

                    
                    <div class="blog-sidebar mb-40">

                        <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/care7.jpg" width="256" height="284" alt="Banner"></a></div>

                    </div>

                   


                </div>

            </div>
        </div>
    </div>
    @endsection