 @extends('layouts.website')
 
 
  @section('contents')

    <div class="page-banner-section section">
        <div class="page-banner-wrap row row-0 d-flex align-items-center ">

            <!-- Page Banner -->
            <div class="col-lg-4 col-12 order-lg-2 d-flex align-items-center justify-content-center">
                <div class="page-banner">
                    <h1>Dog's info</h1>
                    <p>similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita</p>
                    <div class="breadcrumb">
                        <ul>
                            <li><a href="index.html">HOME</a></li>
                            <li><a href="bear.html">dog's info</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Banner -->
            <div class="col-lg-4 col-md-6 col-12 order-lg-1">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/247723.jpg" width="570" height="232" alt="Banner"></a></div>
            </div>

            <!-- Banner -->
            <div class="col-lg-4 col-md-6 col-12 order-lg-3">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/kulu.jpg" width="570" height="232" alt="Banner"></a></div>
            </div>

        </div>
    </div>
    <!-- Page Banner Section End -->

    <!-- Single Product Section Start -->
    <div class="product-section section mt-90 mb-90">
        <div class="container">

            <div class="row mb-90">

                <div class="col-lg-6 col-12 mb-50">

                    <!-- Image -->
                    <div class="single-product-image thumb-right">

                    <div class="tab-content">
                        <div id="single-image-1" class="tab-pane fade show active big-image-slider">
                           
                           
                            <div class="big-image"><img src="{{asset('contents/website')}}/images/single-product/bear.jpg" alt="Big Image"><a href="{{asset('contents/website')}}/images/single-product/bear.jpg" class="big-image-popup"><i class="fa fa-search-plus"></i></a></div>
                        </div>
                       
                       
                    </div>
                    
                   

                </div>

                </div>

                <div class="col-lg-6 col-12 mb-50">

                    <!-- Content -->
                     <div class="single-product-content">

                        <!-- Category & Title -->
                        <div class="head-content">

                            <div class="category-title">
                               
                                <h5 class="title">Bear</h5>
                            </div>

                            <h5 class="price">price negotiable</h5>

                        </div>

                        <div class="single-product-description">



                            <div class="tags">

                                <h5>Breed name:</h5>
                                <a href="#">Norwegian Elkhound</a>


                            </div>

                            <span class="availability">Contact with owner: <span>017XXXXX</span></span>




                            <div class="tags">

                                <h5>Tags:</h5>
                                <a href="#">Norwegian Elkhound</a>
                                

                            </div>

                            <div class="share">

                                <h5>Share: </h5>
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>

                            </div>

                        </div>

                    </div>

                </div>

            </div>



        </div>
    </div>
    <!-- Single Product Section End -->


    <div class="product-section section mb-60">
        <div class="container">
            <div class="row">

                <!-- Section Title Start -->
                <div class="col-12 mb-40">
                    <div class="section-title-one" data-title="Also Related ">
                        <h1>Also Related</h1>
                    </div>
                </div>
                <!-- Section Title End -->

                <div class="col-12">
                    <div class="row">

                        <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">
                            <!-- Product Start -->
                            <div class="ee-product">

                                <!-- Image -->
                                <div class="image">

                                    <a href="romeo-juliet.html" class="img"><img src="{{asset('contents/website')}}/images/product/romeo.jpg" alt="Product Image"height="320" wight="270"></a>


                                </div>

                                <!-- Content -->
                                <div class="content">

                                    <!-- Category & Title -->
                                    <div class="category-title">


                                        <h5 class="title"><a href="romeo-juliet.html">Romeo-Juliet</a></h5>

                                    </div>

                                    <!-- Price & Ratting -->

                                </div>

                            </div>
                            <!-- Product End -->
                        </div>

                        <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">
                            <!-- Product Start -->
                            <div class="ee-product">

                                <!-- Image -->
                                <div class="image">



                                    <a href="duck.html" class="img"><img src="{{asset('contents/website')}}/images/product/duck.jpg" alt="Product Image"height="320" wight="270"></a>


                                </div>

                                <!-- Content -->
                                <div class="content">

                                    <!-- Category & Title -->
                                    <div class="category-title">


                                        <h5 class="title"><a href="duck.html">Duck</a></h5>

                                    </div>

                                    <!-- Price & Ratting -->


                                </div>

                            </div>
                            <!-- Product End -->
                        </div>

                        <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">
                            <!-- Product Start -->
                            <div class="ee-product">

                                <!-- Image -->
                                <div class="image">

                                    <a href="buddy.html" class="img"><img src="{{asset('contents/website')}}/images/product/buddy.jpg" alt="Product Image"height="320" wight="270"></a>


                                </div>

                                <!-- Content -->
                                <div class="content">

                                    <!-- Category & Title -->
                                    <div class="category-title">


                                        <h5 class="title"><a href="buddy.html">Buddy</a></h5>

                                    </div>

                                    <!-- Price & Ratting -->


                                </div>

                            </div>
                            <!-- Product End -->
                        </div>

                        <div class="col-xl-3 col-lg-4 col-md-6 col-12 pb-30 pt-10">
                            <!-- Product Start -->
                            <div class="ee-product">

                                <!-- Image -->
                                <div class="image">



                                    <a href="harry.html" class="img"><img src="{{asset('contents/website')}}/images/product/harry.jpg" alt="Product Image"height="320" wight="270"></a>


                                </div>

                                <!-- Content -->
                                <div class="content">

                                    <!-- Category & Title -->
                                    <div class="category-title">


                                        <h5 class="title"><a href="harry.html">Harry</a></h5>

                                    </div>

                                    <!-- Price & Ratting -->

                                </div>

                            </div>
                            <!-- Product End -->
                        </div>


                    </div>



                </div>
                <!-- Product End -->
            </div>




            <!-- Product End -->
        </div>

    </div>



@endsection