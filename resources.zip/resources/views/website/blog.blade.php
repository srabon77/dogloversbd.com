 @extends('layouts.website')
 
 
  @section('contents')



<div class="page-banner-section section">
    <div class="page-banner-wrap row row-0 d-flex align-items-center ">

        
        <div class="col-lg-4 col-12 order-lg-2 d-flex align-items-center justify-content-center">
            <div class="page-banner">
                <h1>Contact</h1>
               
                <div class="breadcrumb">
                    <ul>
                        <li><a href="index.html">HOME</a></li>
                        <li><a href="blog.html">Blog</a></li>
                    </ul>
                </div>
            </div>
        </div>

        
        <div class="col-lg-4 col-md-6 col-12 order-lg-1">
            <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/Dog-Care-Services.jpg"weidth="570" height="232" alt="Banner"></a></div>
        </div>

        
        <div class="col-lg-4 col-md-6 col-12 order-lg-3">
            <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/lkl.jpg"weidth="570" height="232" alt="Banner"></a></div>
        </div>

    </div>
</div>
   
   
   
   
   
   <div class="blog-section section mt-90 mb-50">
    <div class="container">
        <div class="row row-40">
           
            <div class="col-lg-8 col-12 order-1 order-lg-2 mb-40">
                <div class="row">
                    
                    
                    
                     <div class="col-12 mb-40">
                        <div class="ee-blog">
                            <div class="content">
                                <h3><a href=https://www.facebook.com/groups/18942203408>Facebook Community</a></h3>
                               
                            
                            </div>
                            <a href="health.html" class="image"><img src="{{asset('contents/website')}}/images/blog/blog%20(2).png"width="770" height="386" alt="Blog Image"></a>
                           
                        </div>
                    </div>
                    
                    <div class="col-12 mb-40">
                        <div class="ee-blog">
                           <div class="content">
                                <h3><a href=https://www.facebook.com/groups/18942203408>our facebook group</a></h3>
                                <p>join group and get updated</p>
                               
                             
                            </div>
                            <a href="health.html" class="image"><img src="{{asset('contents/website')}}/images/blog/blog%20(3).png"width="770" height="386" alt="Blog Image"></a>
                            
                        </div>
                    </div>
                    
                     <div class="col-12 mb-40">
                        <div class="ee-blog">
                            <div class="content">
                                <h3><a href=https://www.facebook.com/groups/18942203408>get informed about dog</a></h3>
                               
                            
                            </div>
                            <a href="health.html" class="image"><img src="{{asset('contents/website')}}/images/blog/blog%20(4).png"width="770" height="386" alt="Blog Image"></a>
                           
                        </div>
                    </div>
                    
                    <div class="col-12 mb-40">
                        <div class="ee-blog">
                           <div class="content">
                                <h3><a href=https://www.facebook.com/groups/18942203408>share any dog lovers article</a></h3>
                               
                             
                            </div>
                            <a href="health.html" class="image"><img src="{{asset('contents/website')}}/images/blog/blog%20(5).png"width="770" height="386" alt="Blog Image"></a>
                            
                        </div>
                    </div>
                     <div class="col-12 mb-40">
                        <div class="ee-blog">
                           <div class="content">
                                <h3><a href=https://www.facebook.com/groups/18942203408>posing any video</a></h3>
                               
                             
                            </div>
                            <a href="health.html" class="image"><img src="{{asset('contents/website')}}/images/blog/blogg.png"width="770" height="386" alt="Blog Image"></a>
                            
                        </div>
                    </div>
                    

                </div>

                
               
            </div>
            
            <div class="col-lg-4 col-12 order-2 order-lg-1">
                
                
                <div class="blog-sidebar mb-40">
                   
                    <h4 class="title">CATEGORIES</h4>
                    
                    <ul>
                        <li><a href="oliver.html">Labrador Retriever</a></li>
                        <li><a href="rick-martin.html">Bulldog</a></li>
                        <li><a href="harry.html">Beagle</a></li>
                        <li><a href="tiger.html">Shiba Inu</a></li>
                        <li><a href="bear.html">German Shepherd</a></li>
                        <li><a href="tuck.html">Finnish Spitz</a></li>
                        <li><a href="cooper.html">Golden Retriever</a></li>
                        <li><a href="duck.html">Rhodesian Ridgeback</a></li>
                        
                    </ul>
                    
                </div>
                
               
                <div class="blog-sidebar mb-40">
                   
                    <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/lol.jpg" width="256" height="284" alt="Banner"></a></div>
                    
                </div>
                
              
               
                
            </div>
            
        </div>
    </div>
</div>
    
    
    @endsection
    
    
    
    
    
    
    
    
    
    
    
    
    