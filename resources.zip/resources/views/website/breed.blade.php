 @extends('layouts.website')
 
 
  @section('contents')


    <div class="page-banner-section section">
        <div class="page-banner-wrap row row-0 d-flex align-items-center ">

        
            <div class="col-lg-4 col-12 order-lg-2 d-flex align-items-center justify-content-center">
                <div class="page-banner">
                    <h1>Events</h1>
                    <p>similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita</p>
                    <div class="breadcrumb">
                        <ul>
                            <li><a href="index.html">HOME</a></li>
                            <li><a href="breed.html">Breed</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4 col-md-6 col-12 order-lg-1">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/small-dog-breeds.jpg"weidth="570" height="232" alt="Banner"></a></div>
            </div>

        
            <div class="col-lg-4 col-md-6 col-12 order-lg-3">
                <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/do.png"weidth="570" height="232" alt="Banner"></a></div>
            </div>

        </div>
    </div>
    

    <div class="blog-section section mt-90 mb-50">
        <div class="container">
            <div class="row row-40">

                <div class="col-lg-8 col-12 order-1 order-lg-2 mb-40">

                    <center>
                        <h1>Types of dogs breed</h1>
                    </center>



                    <div class="row">



                        <div class="col-12 mb-40">
                            <div class="ee-blog">
                               <div class="content">
                                    <h3>Labrador Retriever</h3>
                                    <p>The Labrador Retriever, or just Labrador, is a large type of retriever-gun dog. The Labrador is one of the most popular breeds of dog in Canada, the United Kingdom and the United States.</p>


                                </div>
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/Labrador%20Retriever.jpg"width="770" height="386" alt="Blog Image"></a>
                                
                            </div>
                        </div>

                        <div class="col-12 mb-40">
                            <div class="ee-blog">
                                <div class="content">
                                    <h3>Bulldog</h3>
                                    <p>The Bulldog, also known as the British Bulldog or English Bulldog, is a medium-sized breed of dog. It is a muscular, hefty dog with a wrinkled face and a distinctive pushed-in nose. The American Kennel Club, The Kennel Club, and the United Kennel Club oversee breeding records.</p>


                                </div>
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/bulldog.jpg"width="770" height="386" alt="Blog Image"></a>
                               
                            </div>
                        </div>

                        <div class="col-12 mb-40">
                            <div class="ee-blog">
                               <div class="content">
                                    <h3>Beagle</h3>
                                    <p>The beagle is a breed of small hound that is similar in appearance to the much larger foxhound. The beagle is a scent hound, developed primarily for hunting hare.</p>


                                </div>
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/Beagle.jpg"width="770" height="386" alt="Blog Image"></a>
                                
                            </div>
                        </div>

                        <div class="col-12 mb-40">
                            <div class="ee-blog">
                               <div class="content">
                                    <h3>Shiba Inu</h3>
                                    <p>The Shiba Inu is the smallest of the six original and distinct spitz breeds of dog native to Japan. A small, agile dog that copes very well with mountainous terrain, the Shiba Inu was originally bred for hunting.</p>


                                </div>
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/shiba.jpg"width="770" height="386" alt="Blog Image"></a>
                                
                            </div>
                        </div>
                        
                        <div class="col-12 mb-40">
                            <div class="ee-blog">
                                <div class="content">
                                    <h3>Rhodesian Ridgeback</h3>
                                    <p>The Rhodesian Ridgeback is a dog breed developed in the Southern Africa region. Its forebears can be traced to the semi-domesticated, ridged hunting dogs of the Khoikhoi, which were crossed with European dogs by the early colonists of the Cape Colony of southern Africa.</p>


                                </div>
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/Rhodesian Ridgeback.jpg"width="770" height="386" alt="Blog Image"></a>
                               
                            </div>
                        </div>
                        
                         <div class="col-12 mb-40">
                            <div class="ee-blog">
                                <div class="content">
                                    <h3>Norwegian Elkhound</h3>
                                    <p>The Norwegian Elkhound is one of the ancient Northern Spitz-type breed of dog and is the National Dog of Norway. The Elkhound has served as a hunter, guardian, herder, and defender. It is known for its courage in tracking and hunting moose and other large game, such as bears or wolves.</p>


                                </div>
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/Norwegian Elkhound.jpg"width="770" height="386" alt="Blog Image"></a>
                               
                            </div>
                        </div>
                        
                        <div class="col-12 mb-40">
                            <div class="ee-blog">
                                <div class="content">
                                    <h3>Thai ridgeback</h3>
                                    <p>The Thai Ridgeback is an ancient landrace of dog, recently established also as a standardized breed. The breed was formerly unknown outside Thailand, but is gaining notice in the Western world. They are also known as a Mah Thai Lang Ahn.</p>


                                </div>
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/Thai ridgeback.jpg"width="770" height="386" alt="Blog Image"></a>
                               
                            </div>
                        </div>
                        
                         <div class="col-12 mb-40">
                            <div class="ee-blog">
                                <div class="content">
                                    <h3>Finnish Spitz</h3>
                                    <p>A Finnish Spitz is a breed of dog originating in Finland. The breed was originally bred to hunt all types of game from squirrels and other rodents to bears. It is a "bark pointer", indicating the position of game by barking, and drawing the game animal's attention to itself, allowing an easier approach for the hunter.</p>


                                </div>
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/Finnish Spitz.jpg"width="770" height="386" alt="Blog Image"></a>
                               
                            </div>
                        </div>
                        
                         <div class="col-12 mb-40">
                            <div class="ee-blog">
                                <div class="content">
                                    <h3>German Shepherd</h3>
                                    <p>The German Shepherd is a breed of medium to large-sized working dog that originated in Germany. In the English language, the breed's officially recognized name is German Shepherd Dog. The breed was officially known as the Alsatian in Britain until 1977 when its name was changed back to German Shepherd.</p>


                                </div>
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/German Shepherd.jpg"width="770" height="386" alt="Blog Image"></a>
                               
                            </div>
                        </div>
                        
                         <div class="col-12 mb-40">
                            <div class="ee-blog">
                                <div class="content">
                                    <h3>Golden Retriever</h3>
                                    <p>The Golden Retriever is a large-sized breed of dog bred as gun dogs to retrieve shot waterfowl, such as ducks and upland game birds, during hunting and shooting parties, and were named 'retriever' because of their ability to retrieve shot game undamaged.</p>


                                </div>
                                <a href="#" class="image"><img src="{{asset('contents/website')}}/images/blog/Golden Retriever.jpg"width="770" height="386" alt="Blog Image"></a>
                               
                            </div>
                        </div>



                    </div>



                </div>

                <div class="col-lg-4 col-12 order-2 order-lg-1">

                
                    <div class="blog-sidebar mb-40">

                        <h4 class="title">CATEGORIES</h4>

                        <ul>
                        <li><a href="oliver.html">Labrador Retriever</a></li>
                        <li><a href="rick-martin.html">Bulldog</a></li>
                        <li><a href="harry.html">Beagle</a></li>
                        <li><a href="tiger.html">Shiba Inu</a></li>
                        <li><a href="bear.html">German Shepherd</a></li>
                        <li><a href="tuck.html">Finnish Spitz</a></li>
                        <li><a href="cooper.html">Golden Retriever</a></li>
                        <li><a href="duck.html">Rhodesian Ridgeback</a></li>
                        
                    </ul>

                    </div>

                    


                    <!-- Blog Sidebar -->
                    <div class="blog-sidebar mb-40">

                        <div class="banner"><a href="#"><img src="{{asset('contents/website')}}/images/banner/lol.jpg" width="256" height="284" alt="Banner"></a></div>

                    </div>

                    


                </div>

            </div>
        </div>
    </div>
    
    @endsection

